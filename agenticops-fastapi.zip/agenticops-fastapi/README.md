# AgenticOps FastAPI Reference Stack

A Docker-first FastAPI implementation of a three-tier AgenticOps ecosystem:

1. **Agentic Layer** — specialized agents for diagnostics, optimization, fraud detection, and security scanning.
2. **Orchestration Control Plane** — deterministic workflow engine with explicit sequencing, policy validation, and human approval gates.
3. **MCP-style Integration Facade** — JSON-RPC endpoint exposing tools through a consistent `tools/list` and `tools/call` interface.

This is intentionally practical: local Docker, SQLite persistence, API-key admin auth, Telegram bot/Mini App hooks, ngrok tunnel profile, and constrained Nmap execution for authorized defensive scanning.

## Security posture

The Nmap integration is fail-closed:

- scans only one target at a time;
- rejects CIDR sweeps, ranges, URLs, wildcards, and shell fragments;
- allows only configured CIDRs and explicitly allowlisted hostnames;
- uses bounded `--top-ports`, timeout, and TCP connect scan;
- requires human approval by default before execution.

Do not loosen those defaults unless you control the target environment. "It was just a scan" is not a compliance strategy.

## Quick start

```bash
cp .env.example .env
# Edit .env and set ADMIN_API_KEY to a real secret.
docker compose up --build app
```

Open:

- API docs: `http://localhost:8000/docs`
- Health: `http://localhost:8000/healthz`
- Telegram Mini App shell: `http://localhost:8000/static/miniapp.html`

## Start a diagnostics workflow

```bash
curl -s http://localhost:8000/workflows \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-me-now' \
  -d '{"kind":"diagnostics","target":"localhost","context":{"signals":{"cpu_percent":34,"p95_latency_ms":120}}}' | jq
```

## Start an approved security scan

The first call creates a pending approval. The second call approves it. The third call resumes execution.

```bash
curl -s http://localhost:8000/workflows \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-me-now' \
  -d '{"kind":"security_scan","target":"localhost","context":{"top_ports":25}}' | jq

curl -s http://localhost:8000/approvals \
  -H 'X-API-Key: change-me-now' | jq

curl -s http://localhost:8000/approvals/<approval_id>/decision \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-me-now' \
  -d '{"approve":true,"reason":"authorized local validation"}' | jq

curl -s -X POST http://localhost:8000/workflows/<workflow_id>/resume \
  -H 'X-API-Key: change-me-now' | jq
```

## MCP-style calls

```bash
curl -s http://localhost:8000/mcp \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-me-now' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | jq
```

Start a workflow through the facade:

```bash
curl -s http://localhost:8000/mcp \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-me-now' \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"ops.start_workflow","arguments":{"kind":"fraud_detection","context":{"transactions":[{"id":"tx1","amount":1500,"country":"NG","home_country":"US","velocity_count":7}]}}}}' | jq
```

## ngrok tunnel

```bash
# Put NGROK_AUTHTOKEN in .env first.
docker compose --profile tunnel up --build
```

Use the generated HTTPS URL for Telegram webhook and Mini App testing.

Set Telegram webhook:

```bash
curl -s "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" \
  -d "url=https://YOUR-NGROK-DOMAIN.ngrok-free.app/telegram/webhook" \
  -d "secret_token=$TELEGRAM_WEBHOOK_SECRET"
```

## Telegram bot commands

- `/start` — help text
- `/security localhost` — creates a security scan workflow and requests approval
- `/approve <approval_id>` — approves and resumes the workflow
- `/reject <approval_id>` — rejects the workflow

Set `TELEGRAM_ALLOWED_USER_IDS` to a comma-separated list before exposing the webhook. Public bots without an allowlist are how demos become incident reports.

## Telegram Mini App

Point your BotFather Mini App URL to your HTTPS ngrok URL:

```text
https://YOUR-NGROK-DOMAIN.ngrok-free.app/static/miniapp.html
```

The Mini App sends Telegram `initData` to `/telegram/miniapp/auth`; the backend validates the HMAC before trusting user identity or `is_premium`.

## Production upgrade path

Keep this implementation as the control-plane skeleton, then upgrade in this order:

1. Move SQLite to Postgres.
2. Replace API key auth with OIDC/JWT and RBAC.
3. Add signed approval attestations and audit log immutability.
4. Deploy behind a real ingress with WAF and mTLS where appropriate.
5. Put agent execution on a queue/worker model for long-running workflows.
6. Promote the MCP facade to a full MCP server transport if your client expects stdio/SSE semantics.

## Project layout

```text
app/
  agents/            specialized agent implementations
  control_plane/     deterministic orchestrator
  core/              runtime settings
  integrations/      Telegram client
  mcp/               JSON-RPC MCP-style facade
  security/          auth and scan policy
  storage/           SQLite persistence
  tools/             constrained tool wrappers, including Nmap
tests/               policy and Telegram validation tests
```
