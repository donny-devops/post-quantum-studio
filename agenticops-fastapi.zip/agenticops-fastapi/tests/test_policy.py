from app.core.config import get_settings
from app.security.policy import validate_single_scan_target


def test_policy_allows_localhost_by_default():
    get_settings.cache_clear()
    settings = get_settings()
    decision = validate_single_scan_target("localhost", settings)
    assert decision.allowed is True


def test_policy_rejects_external_hostname_by_default():
    get_settings.cache_clear()
    settings = get_settings()
    decision = validate_single_scan_target("example.com", settings)
    assert decision.allowed is False
    assert "not explicitly allowlisted" in decision.reason


def test_policy_rejects_cidr_sweeps():
    get_settings.cache_clear()
    settings = get_settings()
    decision = validate_single_scan_target("127.0.0.0/24", settings)
    assert decision.allowed is False
