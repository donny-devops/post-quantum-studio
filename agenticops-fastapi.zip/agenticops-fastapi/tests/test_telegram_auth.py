import hashlib
import hmac
import json
import time
from urllib.parse import urlencode

import pytest

from app.security.auth import TelegramAuthError, validate_telegram_init_data


def make_init_data(bot_token: str, fields: dict[str, str]) -> str:
    data_check_string = "\n".join(f"{key}={value}" for key, value in sorted(fields.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    digest = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    return urlencode({**fields, "hash": digest})


def test_validate_telegram_init_data_accepts_valid_signature():
    bot_token = "123456:test-token"
    fields = {
        "auth_date": str(int(time.time())),
        "query_id": "abc",
        "user": json.dumps({"id": 42, "first_name": "Ada", "is_premium": True}, separators=(",", ":")),
    }
    init_data = make_init_data(bot_token, fields)
    trusted = validate_telegram_init_data(init_data, bot_token)
    assert trusted["user"]["id"] == 42
    assert trusted["user"]["is_premium"] is True


def test_validate_telegram_init_data_rejects_tampering():
    bot_token = "123456:test-token"
    fields = {"auth_date": str(int(time.time())), "query_id": "abc"}
    init_data = make_init_data(bot_token, fields).replace("abc", "evil")
    with pytest.raises(TelegramAuthError):
        validate_telegram_init_data(init_data, bot_token)
