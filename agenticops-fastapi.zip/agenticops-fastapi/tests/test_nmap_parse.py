from app.tools.nmap_tool import NmapTool


def test_parse_nmap_xml_open_port():
    xml = """<?xml version='1.0'?>
    <nmaprun>
      <host>
        <status state="up" reason="localhost-response" />
        <address addr="127.0.0.1" addrtype="ipv4" />
        <ports>
          <port protocol="tcp" portid="80">
            <state state="open" reason="syn-ack" />
            <service name="http" method="table" conf="3" />
          </port>
        </ports>
      </host>
    </nmaprun>"""
    parsed = NmapTool._parse_xml(xml, "localhost", 10)
    assert parsed["hosts"][0]["ports"][0]["state"] == "open"
    assert parsed["hosts"][0]["ports"][0]["service"]["name"] == "http"
