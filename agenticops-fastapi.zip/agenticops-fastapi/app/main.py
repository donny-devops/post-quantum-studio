from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.control_plane.orchestrator import Orchestrator
from app.core.config import get_settings
from app.integrations.telegram import TelegramBotClient
from app.mcp.facade import handle_mcp
from app.models import ApprovalDecision, MCPRequest, WorkflowCreate, WorkflowResponse
from app.security.auth import (
    require_api_key,
    require_telegram_user,
    validate_telegram_init_data,
    verify_telegram_webhook_secret,
    TelegramAuthError,
)
from app.storage import db


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    yield


settings = get_settings()
app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)

if settings.cors_origin_list:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.mount("/static", StaticFiles(directory="app/static"), name="static")


@app.get("/", response_class=HTMLResponse)
async def root() -> str:
    return """
    <html>
      <head><title>AgenticOps</title></head>
      <body style="font-family: system-ui; max-width: 800px; margin: 4rem auto;">
        <h1>AgenticOps Control Plane</h1>
        <p>FastAPI service is online. Use <code>/docs</code> for OpenAPI, <code>/healthz</code> for liveness, and <code>/static/miniapp.html</code> for the Telegram Mini App shell.</p>
      </body>
    </html>
    """


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok", "service": "agenticops-fastapi"}


@app.post("/workflows", response_model=WorkflowResponse)
async def start_workflow(request: WorkflowCreate, actor: str = Depends(require_api_key)) -> WorkflowResponse:
    return await Orchestrator().start(request, actor=actor)


@app.post("/workflows/{workflow_id}/resume", response_model=WorkflowResponse)
async def resume_workflow(workflow_id: str, actor: str = Depends(require_api_key)) -> WorkflowResponse:
    try:
        return await Orchestrator().resume(workflow_id, actor=actor)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@app.get("/workflows")
async def list_workflows(actor: str = Depends(require_api_key), limit: int = 50) -> dict[str, Any]:
    return {"items": [item.model_dump(mode="json") for item in db.list_workflows(limit=min(limit, 100))]}


@app.get("/workflows/{workflow_id}")
async def get_workflow(workflow_id: str, actor: str = Depends(require_api_key)) -> dict[str, Any]:
    try:
        return db.get_workflow(workflow_id).model_dump(mode="json")
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@app.get("/approvals")
async def list_approvals(actor: str = Depends(require_api_key), approval_status: str | None = None) -> dict[str, Any]:
    return {"items": [item.model_dump(mode="json") for item in db.list_approvals(status=approval_status)]}


@app.post("/approvals/{approval_id}/decision")
async def decide_approval(
    approval_id: str,
    decision: ApprovalDecision,
    actor: str = Depends(require_api_key),
) -> dict[str, Any]:
    try:
        approval = db.decide_approval(approval_id, approve=decision.approve, decided_by=actor, reason=decision.reason)
        if not decision.approve:
            db.update_workflow(approval.workflow_id, status="rejected", error=decision.reason or "Approval rejected")
        return approval.model_dump(mode="json")
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@app.post("/mcp")
async def mcp_endpoint(request: MCPRequest, actor: str = Depends(require_api_key)) -> dict[str, Any]:
    return await handle_mcp(request, actor=actor)


@app.post("/telegram/miniapp/auth")
async def telegram_miniapp_auth(payload: dict[str, str]) -> dict[str, Any]:
    init_data = payload.get("initData", "")
    try:
        trusted = validate_telegram_init_data(
            init_data,
            settings.telegram_bot_token,
            settings.telegram_init_data_max_age_seconds,
        )
    except TelegramAuthError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc
    user = trusted.get("user") or {}
    return {
        "ok": True,
        "user": user,
        "is_premium": bool(user.get("is_premium")),
        "premium_features": ["priority_security_scan", "workflow_notifications"] if user.get("is_premium") else [],
    }


@app.post("/telegram/miniapp/workflows")
async def telegram_miniapp_workflow(
    request: WorkflowCreate,
    trusted: dict[str, Any] = Depends(require_telegram_user),
) -> dict[str, Any]:
    user = trusted.get("user") or {}
    actor = f"telegram:{user.get('id', 'unknown')}"
    response = await Orchestrator().start(request, actor=actor)
    return response.model_dump(mode="json")


@app.post("/telegram/webhook", dependencies=[Depends(verify_telegram_webhook_secret)])
async def telegram_webhook(update: dict[str, Any]) -> dict[str, bool]:
    message = update.get("message") or update.get("edited_message") or {}
    text = (message.get("text") or "").strip()
    chat = message.get("chat") or {}
    from_user = message.get("from") or {}
    chat_id = chat.get("id")
    user_id = from_user.get("id")

    allowed_users = settings.allowed_telegram_user_id_list
    client = TelegramBotClient(settings)
    if allowed_users and int(user_id or 0) not in allowed_users:
        if client.configured and chat_id:
            await client.send_message(chat_id, "Access denied. This bot is allowlist-only.")
        return {"ok": True}

    if not text or not chat_id:
        return {"ok": True}

    if text.startswith("/start") or text.startswith("/help"):
        if client.configured:
            await client.send_message(
                chat_id,
                "AgenticOps online. Commands: /security localhost, /approve <approval_id>, /reject <approval_id>.",
            )
        return {"ok": True}

    if text.startswith("/security"):
        parts = text.split(maxsplit=1)
        target = parts[1] if len(parts) > 1 else "localhost"
        workflow = WorkflowCreate(kind="security_scan", target=target, context={}, notify_telegram_chat_id=str(chat_id))
        response = await Orchestrator().start(workflow, actor=f"telegram:{user_id}")
        if client.configured:
            await client.send_message(chat_id, response.message)
        return {"ok": True}

    if text.startswith("/approve") or text.startswith("/reject"):
        parts = text.split(maxsplit=1)
        if len(parts) != 2:
            if client.configured:
                await client.send_message(chat_id, "Usage: /approve <approval_id> or /reject <approval_id>")
            return {"ok": True}
        approve = text.startswith("/approve")
        try:
            approval = db.decide_approval(parts[1], approve=approve, decided_by=f"telegram:{user_id}", reason="telegram decision")
            if approve:
                response = await Orchestrator().resume(approval.workflow_id, actor=f"telegram:{user_id}")
                reply = response.message
            else:
                db.update_workflow(approval.workflow_id, status="rejected", error="Rejected from Telegram")
                reply = "Workflow rejected."
        except Exception as exc:
            reply = f"Decision failed: {exc}"
        if client.configured:
            await client.send_message(chat_id, reply)
        return {"ok": True}

    if client.configured:
        await client.send_message(chat_id, "Unknown command. Try /help.")
    return {"ok": True}
