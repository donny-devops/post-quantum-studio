import ipaddress
import re
import socket
from dataclasses import dataclass

from app.core.config import Settings

_HOST_RE = re.compile(r"^[a-zA-Z0-9.-]{1,253}$")


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str


def _allowed_networks(settings: Settings) -> list[ipaddress._BaseNetwork]:
    networks: list[ipaddress._BaseNetwork] = []
    for item in settings.allowed_cidr_list:
        networks.append(ipaddress.ip_network(item, strict=False))
    return networks


def validate_single_scan_target(target: str, settings: Settings) -> PolicyDecision:
    """Fail-closed target validation for defensive Nmap scans.

    This intentionally accepts only a single hostname/IP. CIDR ranges, URLs, shell fragments,
    wildcard ranges, and comma-separated targets are rejected.
    """
    clean_target = (target or "").strip()
    if not clean_target:
        return PolicyDecision(False, "target is required")
    if len(clean_target) > 253:
        return PolicyDecision(False, "target is too long")
    if any(token in clean_target for token in ["/", "\\", ",", " ", "\t", "\n", "*", "?", ";", "&", "|"]):
        return PolicyDecision(False, "target must be one hostname or one IP address, not a range, URL, or shell expression")

    lowered = clean_target.lower()
    if lowered in settings.allowed_hostname_list:
        return PolicyDecision(True, "hostname is explicitly allowed")

    networks = _allowed_networks(settings)
    try:
        ip = ipaddress.ip_address(clean_target)
        if any(ip in network for network in networks):
            return PolicyDecision(True, "IP is inside allowed CIDR policy")
        return PolicyDecision(False, f"IP {ip} is outside allowed CIDR policy")
    except ValueError:
        pass

    if not _HOST_RE.match(clean_target) or ".." in clean_target or clean_target.startswith("-"):
        return PolicyDecision(False, "target is not a valid hostname")

    # Hostnames must be explicitly allowlisted. This avoids DNS rebinding surprises and
    # accidental scans of third-party infrastructure.
    return PolicyDecision(False, "hostname is not explicitly allowlisted")


def resolve_allowed_hostname(target: str, settings: Settings) -> list[str]:
    decision = validate_single_scan_target(target, settings)
    if not decision.allowed:
        raise PermissionError(decision.reason)
    try:
        return sorted({result[4][0] for result in socket.getaddrinfo(target, None)})
    except socket.gaierror:
        return []
