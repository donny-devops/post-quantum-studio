import hashlib
import hmac
import json
import time
from typing import Any
from urllib.parse import parse_qsl

from fastapi import Depends, Header, HTTPException, Request, status
from fastapi.security import APIKeyHeader

from app.core.config import Settings, get_settings

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def require_api_key(
    token: str | None = Depends(api_key_header),
    settings: Settings = Depends(get_settings),
) -> str:
    if not token or not hmac.compare_digest(token, settings.admin_api_key):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")
    return "api-key-admin"


class TelegramAuthError(ValueError):
    pass


def validate_telegram_init_data(
    init_data: str,
    bot_token: str,
    max_age_seconds: int = 86400,
) -> dict[str, Any]:
    """Validate Telegram Mini App initData and return trusted decoded fields.

    This follows Telegram WebApp initData HMAC validation:
    - remove hash
    - build sorted data-check-string
    - derive secret with HMAC_SHA256(key="WebAppData", msg=bot_token)
    - compare against provided hash
    """
    if not bot_token:
        raise TelegramAuthError("TELEGRAM_BOT_TOKEN is not configured")
    if not init_data:
        raise TelegramAuthError("Missing initData")

    pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=False))
    provided_hash = pairs.pop("hash", None)
    if not provided_hash:
        raise TelegramAuthError("Missing hash")

    auth_date_raw = pairs.get("auth_date")
    if not auth_date_raw or not auth_date_raw.isdigit():
        raise TelegramAuthError("Missing or invalid auth_date")
    auth_date = int(auth_date_raw)
    now = int(time.time())
    if auth_date > now + 60:
        raise TelegramAuthError("auth_date is in the future")
    if now - auth_date > max_age_seconds:
        raise TelegramAuthError("initData is expired")

    data_check_string = "\n".join(f"{key}={value}" for key, value in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calculated_hash, provided_hash):
        raise TelegramAuthError("Invalid Telegram initData signature")

    trusted: dict[str, Any] = dict(pairs)
    if "user" in trusted:
        try:
            trusted["user"] = json.loads(trusted["user"])
        except json.JSONDecodeError as exc:
            raise TelegramAuthError("Invalid user JSON") from exc
    return trusted


def require_telegram_user(
    x_telegram_init_data: str | None = Header(default=None, alias="X-Telegram-Init-Data"),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    try:
        trusted = validate_telegram_init_data(
            x_telegram_init_data or "",
            settings.telegram_bot_token,
            settings.telegram_init_data_max_age_seconds,
        )
    except TelegramAuthError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc

    user = trusted.get("user") or {}
    user_id = user.get("id")
    allowed = settings.allowed_telegram_user_id_list
    if allowed and int(user_id or 0) not in allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Telegram user is not allowed")
    return trusted


async def verify_telegram_webhook_secret(
    request: Request,
    settings: Settings = Depends(get_settings),
) -> None:
    if not settings.telegram_webhook_secret:
        return
    received = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if not hmac.compare_digest(received, settings.telegram_webhook_secret):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Telegram webhook secret")
