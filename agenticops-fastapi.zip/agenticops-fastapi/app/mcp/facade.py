from typing import Any

from app.control_plane.orchestrator import Orchestrator
from app.core.config import get_settings
from app.models import MCPRequest, WorkflowCreate
from app.storage import db
from app.tools.nmap_tool import NmapTool


def ok(request_id: str | int | None, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def err(request_id: str | int | None, code: int, message: str, data: Any | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        payload["data"] = data
    return {"jsonrpc": "2.0", "id": request_id, "error": payload}


async def handle_mcp(request: MCPRequest, actor: str) -> dict[str, Any]:
    if request.method == "initialize":
        return ok(
            request.id,
            {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "agenticops-fastapi", "version": "0.1.0"},
                "capabilities": {"tools": {}},
            },
        )

    if request.method == "tools/list":
        return ok(
            request.id,
            {
                "tools": [
                    {
                        "name": "ops.start_workflow",
                        "description": "Start a deterministic AgenticOps workflow.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "kind": {"type": "string"},
                                "target": {"type": "string"},
                                "context": {"type": "object"},
                            },
                            "required": ["kind"],
                        },
                    },
                    {
                        "name": "nmap.scan",
                        "description": "Run a constrained defensive Nmap scan against an allowlisted single target.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"target": {"type": "string"}, "top_ports": {"type": "integer"}},
                            "required": ["target"],
                        },
                    },
                    {
                        "name": "ops.get_workflow",
                        "description": "Fetch workflow state by ID.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"workflow_id": {"type": "string"}},
                            "required": ["workflow_id"],
                        },
                    },
                ]
            },
        )

    if request.method == "tools/call":
        name = request.params.get("name")
        arguments = request.params.get("arguments") or {}
        try:
            if name == "ops.start_workflow":
                workflow_request = WorkflowCreate(**arguments)
                response = await Orchestrator().start(workflow_request, actor=actor)
                return ok(request.id, {"content": [{"type": "json", "json": response.model_dump(mode="json")}]})
            if name == "ops.get_workflow":
                workflow = db.get_workflow(arguments["workflow_id"])
                return ok(request.id, {"content": [{"type": "json", "json": workflow.model_dump(mode="json")}]})
            if name == "nmap.scan":
                # Direct MCP tool calls are intentionally policy-bound and approval-free only when the global
                # Nmap approval gate is disabled. Otherwise use ops.start_workflow security_scan.
                if get_settings().require_approval_for_nmap:
                    return err(
                        request.id,
                        -32001,
                        "approval_required",
                        {"hint": "Call ops.start_workflow with kind=security_scan, then approve/resume."},
                    )
                result = NmapTool(get_settings()).scan(arguments["target"], arguments.get("top_ports"))
                return ok(request.id, {"content": [{"type": "json", "json": result}]})
        except Exception as exc:
            return err(request.id, -32000, str(exc))
        return err(request.id, -32602, f"Unknown tool: {name}")

    return err(request.id, -32601, f"Unknown method: {request.method}")
