import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterator

from app.core.config import get_settings
from app.models import ApprovalRecord, WorkflowRecord


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    settings = get_settings()
    conn = sqlite3.connect(settings.database_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS workflows (
                id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                status TEXT NOT NULL,
                target TEXT,
                context_json TEXT NOT NULL,
                result_json TEXT,
                error TEXT,
                current_step INTEGER NOT NULL DEFAULT 0,
                plan_json TEXT NOT NULL,
                approval_id TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS approvals (
                id TEXT PRIMARY KEY,
                workflow_id TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                requested_by TEXT NOT NULL,
                decided_by TEXT,
                decision_reason TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(workflow_id) REFERENCES workflows(id)
            )
            """
        )


def _workflow_from_row(row: sqlite3.Row) -> WorkflowRecord:
    return WorkflowRecord(
        id=row["id"],
        kind=row["kind"],
        status=row["status"],
        target=row["target"],
        context=json.loads(row["context_json"]),
        result=json.loads(row["result_json"]) if row["result_json"] else None,
        error=row["error"],
        current_step=row["current_step"],
        plan=json.loads(row["plan_json"]),
        approval_id=row["approval_id"],
        created_at=datetime.fromisoformat(row["created_at"]),
        updated_at=datetime.fromisoformat(row["updated_at"]),
    )


def _approval_from_row(row: sqlite3.Row) -> ApprovalRecord:
    return ApprovalRecord(
        id=row["id"],
        workflow_id=row["workflow_id"],
        action=row["action"],
        status=row["status"],
        payload=json.loads(row["payload_json"]),
        requested_by=row["requested_by"],
        decided_by=row["decided_by"],
        decision_reason=row["decision_reason"],
        created_at=datetime.fromisoformat(row["created_at"]),
        updated_at=datetime.fromisoformat(row["updated_at"]),
    )


def create_workflow(kind: str, target: str | None, context: dict[str, Any], plan: list[dict[str, Any]]) -> WorkflowRecord:
    workflow_id = new_id("wf")
    now = utcnow_iso()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO workflows (id, kind, status, target, context_json, result_json, error, current_step, plan_json, approval_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (workflow_id, kind, "created", target, json.dumps(context), None, None, 0, json.dumps(plan), None, now, now),
        )
    return get_workflow(workflow_id)


def update_workflow(workflow_id: str, **fields: Any) -> WorkflowRecord:
    allowed = {"status", "target", "context", "result", "error", "current_step", "plan", "approval_id"}
    if not fields:
        return get_workflow(workflow_id)
    assignments: list[str] = []
    values: list[Any] = []
    for key, value in fields.items():
        if key not in allowed:
            raise ValueError(f"Cannot update field: {key}")
        column = {
            "context": "context_json",
            "result": "result_json",
            "plan": "plan_json",
        }.get(key, key)
        assignments.append(f"{column} = ?")
        if key in {"context", "result", "plan"}:
            values.append(json.dumps(value) if value is not None else None)
        else:
            values.append(value)
    assignments.append("updated_at = ?")
    values.append(utcnow_iso())
    values.append(workflow_id)
    with connect() as conn:
        conn.execute(f"UPDATE workflows SET {', '.join(assignments)} WHERE id = ?", tuple(values))
    return get_workflow(workflow_id)


def get_workflow(workflow_id: str) -> WorkflowRecord:
    with connect() as conn:
        row = conn.execute("SELECT * FROM workflows WHERE id = ?", (workflow_id,)).fetchone()
    if not row:
        raise KeyError(f"Workflow not found: {workflow_id}")
    return _workflow_from_row(row)


def list_workflows(limit: int = 50) -> list[WorkflowRecord]:
    with connect() as conn:
        rows = conn.execute("SELECT * FROM workflows ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [_workflow_from_row(row) for row in rows]


def create_approval(workflow_id: str, action: str, payload: dict[str, Any], requested_by: str) -> ApprovalRecord:
    approval_id = new_id("appr")
    now = utcnow_iso()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO approvals (id, workflow_id, action, status, payload_json, requested_by, decided_by, decision_reason, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (approval_id, workflow_id, action, "pending", json.dumps(payload), requested_by, None, None, now, now),
        )
    return get_approval(approval_id)


def get_approval(approval_id: str) -> ApprovalRecord:
    with connect() as conn:
        row = conn.execute("SELECT * FROM approvals WHERE id = ?", (approval_id,)).fetchone()
    if not row:
        raise KeyError(f"Approval not found: {approval_id}")
    return _approval_from_row(row)


def get_pending_approval_for_workflow(workflow_id: str) -> ApprovalRecord | None:
    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM approvals WHERE workflow_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            (workflow_id,),
        ).fetchone()
    return _approval_from_row(row) if row else None


def decide_approval(approval_id: str, approve: bool, decided_by: str, reason: str | None) -> ApprovalRecord:
    status = "approved" if approve else "rejected"
    with connect() as conn:
        conn.execute(
            """
            UPDATE approvals
            SET status = ?, decided_by = ?, decision_reason = ?, updated_at = ?
            WHERE id = ?
            """,
            (status, decided_by, reason, utcnow_iso(), approval_id),
        )
    return get_approval(approval_id)


def list_approvals(status: str | None = None, limit: int = 50) -> list[ApprovalRecord]:
    with connect() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM approvals WHERE status = ? ORDER BY created_at DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM approvals ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [_approval_from_row(row) for row in rows]
