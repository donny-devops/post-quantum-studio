import shutil
import subprocess
import xml.etree.ElementTree as ET
from typing import Any

from app.core.config import Settings
from app.security.policy import validate_single_scan_target


class NmapUnavailable(RuntimeError):
    pass


class NmapPolicyError(PermissionError):
    pass


class NmapTool:
    """Safe Nmap wrapper for authorized defensive scanning only."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def scan(self, target: str, top_ports: int | None = None) -> dict[str, Any]:
        decision = validate_single_scan_target(target, self.settings)
        if not decision.allowed:
            raise NmapPolicyError(decision.reason)

        if shutil.which("nmap") is None:
            raise NmapUnavailable("nmap binary is not installed in this runtime")

        bounded_top_ports = min(max(int(top_ports or self.settings.nmap_top_ports_default), 1), 100)
        timeout = self.settings.nmap_timeout_seconds
        cmd = [
            "nmap",
            "-sT",
            "-Pn",
            "--top-ports",
            str(bounded_top_ports),
            "--max-retries",
            "2",
            "--host-timeout",
            f"{timeout}s",
            "-oX",
            "-",
            target,
        ]
        completed = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout + 10,
        )
        if completed.returncode not in {0, 1}:
            raise RuntimeError(completed.stderr.strip() or "nmap scan failed")
        return self._parse_xml(completed.stdout, target, bounded_top_ports)

    @staticmethod
    def _parse_xml(xml_text: str, target: str, top_ports: int) -> dict[str, Any]:
        root = ET.fromstring(xml_text)
        hosts: list[dict[str, Any]] = []
        for host in root.findall("host"):
            status_node = host.find("status")
            addresses = [addr.attrib for addr in host.findall("address")]
            hostnames = [name.attrib for name in host.findall("hostnames/hostname")]
            ports: list[dict[str, Any]] = []
            for port in host.findall("ports/port"):
                state_node = port.find("state")
                service_node = port.find("service")
                ports.append(
                    {
                        "protocol": port.attrib.get("protocol"),
                        "port": int(port.attrib.get("portid", "0")),
                        "state": state_node.attrib.get("state") if state_node is not None else None,
                        "reason": state_node.attrib.get("reason") if state_node is not None else None,
                        "service": service_node.attrib if service_node is not None else {},
                    }
                )
            hosts.append(
                {
                    "status": status_node.attrib if status_node is not None else {},
                    "addresses": addresses,
                    "hostnames": hostnames,
                    "ports": ports,
                }
            )
        return {
            "tool": "nmap",
            "target": target,
            "top_ports": top_ports,
            "hosts": hosts,
        }
