from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration. All secrets must be injected through env vars."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "AgenticOps Control Plane"
    environment: str = "dev"
    database_path: str = Field(default="/tmp/agenticops.db")

    admin_api_key: str = Field(default="dev-change-me")

    nmap_allowed_cidrs: str = Field(default="127.0.0.1/32,::1/128")
    nmap_allowed_hostnames: str = Field(default="localhost")
    nmap_top_ports_default: int = Field(default=50, ge=1, le=100)
    nmap_timeout_seconds: int = Field(default=45, ge=5, le=180)
    require_approval_for_nmap: bool = True

    telegram_bot_token: str = ""
    telegram_webhook_secret: str = ""
    telegram_allowed_user_ids: str = ""
    telegram_init_data_max_age_seconds: int = Field(default=86400, ge=60)

    cors_origins: str = Field(default="")

    @property
    def allowed_cidr_list(self) -> List[str]:
        return [item.strip() for item in self.nmap_allowed_cidrs.split(",") if item.strip()]

    @property
    def allowed_hostname_list(self) -> List[str]:
        return [item.strip().lower() for item in self.nmap_allowed_hostnames.split(",") if item.strip()]

    @property
    def allowed_telegram_user_id_list(self) -> List[int]:
        output: list[int] = []
        for item in self.telegram_allowed_user_ids.split(","):
            item = item.strip()
            if item:
                output.append(int(item))
        return output

    @property
    def cors_origin_list(self) -> List[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]

    def ensure_db_parent(self) -> None:
        Path(self.database_path).parent.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.ensure_db_parent()
    return settings
