"""AgenticOps FastAPI reference implementation."""
