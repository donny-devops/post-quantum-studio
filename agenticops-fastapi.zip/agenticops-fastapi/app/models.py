from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

WorkflowKind = Literal["diagnostics", "optimization", "fraud_detection", "security_scan"]
WorkflowStatus = Literal["created", "running", "pending_approval", "succeeded", "failed", "rejected"]


class WorkflowCreate(BaseModel):
    kind: WorkflowKind
    target: str | None = Field(default=None, description="Single host/IP for security workflows; optional for others")
    context: dict[str, Any] = Field(default_factory=dict)
    notify_telegram_chat_id: str | None = None


class WorkflowRecord(BaseModel):
    id: str
    kind: str
    status: WorkflowStatus
    target: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    result: dict[str, Any] | None = None
    error: str | None = None
    current_step: int = 0
    plan: list[dict[str, Any]] = Field(default_factory=list)
    approval_id: str | None = None
    created_at: datetime
    updated_at: datetime


class WorkflowResponse(BaseModel):
    workflow: WorkflowRecord
    message: str


class ApprovalRecord(BaseModel):
    id: str
    workflow_id: str
    action: str
    status: Literal["pending", "approved", "rejected"]
    payload: dict[str, Any] = Field(default_factory=dict)
    requested_by: str
    decided_by: str | None = None
    decision_reason: str | None = None
    created_at: datetime
    updated_at: datetime


class ApprovalDecision(BaseModel):
    approve: bool
    reason: str | None = None


class MCPRequest(BaseModel):
    jsonrpc: str = "2.0"
    id: str | int | None = None
    method: str
    params: dict[str, Any] = Field(default_factory=dict)
