from typing import Any

from app.agents.base import Agent


class OptimizationAgent(Agent):
    name = "optimization-agent"
    role = "Prioritizes reliability, cost, and throughput improvements."

    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        signals = context.get("signals", {})
        cpu = float(signals.get("cpu_percent", 0) or 0)
        latency = float(signals.get("p95_latency_ms", 0) or 0)
        recommendations: list[str] = []
        if cpu > 75:
            recommendations.append("CPU pressure is high. Add worker concurrency or right-size compute.")
        if latency > 500:
            recommendations.append("p95 latency is above target. Add caching and isolate slow integrations.")
        if not recommendations:
            recommendations.append("No critical optimization signal detected. Baseline looks clean.")
        return {
            "agent": self.name,
            "score": max(0, 100 - int(cpu * 0.4) - int(latency / 50)),
            "recommendations": recommendations,
        }
