import platform
from typing import Any

from app.agents.base import Agent


class DiagnosticsAgent(Agent):
    name = "diagnostics-agent"
    role = "Collects baseline service diagnostics and operational posture."

    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        target = context.get("target") or "local-service"
        return {
            "agent": self.name,
            "target": target,
            "runtime": {
                "python": platform.python_version(),
                "platform": platform.platform(),
            },
            "findings": [
                "API process is reachable through FastAPI health endpoint.",
                "Control plane state is persisted in SQLite for local-first operations.",
            ],
            "recommendations": [
                "Promote SQLite to Postgres before multi-replica deployment.",
                "Route production ingress through an authenticated gateway, not raw ngrok.",
            ],
        }
