from typing import Any

from app.agents.base import Agent
from app.core.config import get_settings
from app.tools.nmap_tool import NmapTool


class SecurityAgent(Agent):
    name = "security-agent"
    role = "Runs approved defensive surface checks using constrained Nmap execution."

    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        target = context.get("target")
        if not target:
            raise ValueError("security scan requires target")
        top_ports = context.get("top_ports")
        result = NmapTool(get_settings()).scan(target=target, top_ports=top_ports)
        open_ports = []
        for host in result.get("hosts", []):
            for port in host.get("ports", []):
                if port.get("state") == "open":
                    open_ports.append(port)
        return {
            "agent": self.name,
            "scan": result,
            "summary": {
                "open_port_count": len(open_ports),
                "open_ports": open_ports,
            },
            "recommendations": [
                "Close unused listeners or put them behind authenticated ingress.",
                "Track deltas over time; port drift is usually where the gremlins breed.",
            ],
        }
