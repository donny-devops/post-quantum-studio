from typing import Any

from app.agents.base import Agent


class FraudDetectionAgent(Agent):
    name = "fraud-detection-agent"
    role = "Flags anomalous transaction patterns using transparent heuristics."

    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        transactions = context.get("transactions", [])
        high_value_threshold = float(context.get("high_value_threshold", 1000))
        flagged = []
        for tx in transactions:
            amount = float(tx.get("amount", 0) or 0)
            risk = 0
            reasons: list[str] = []
            if amount >= high_value_threshold:
                risk += 60
                reasons.append("high_value_transaction")
            if tx.get("country") and tx.get("home_country") and tx.get("country") != tx.get("home_country"):
                risk += 20
                reasons.append("geo_mismatch")
            if tx.get("velocity_count", 0) >= 5:
                risk += 25
                reasons.append("high_velocity")
            if risk >= 50:
                flagged.append({"transaction_id": tx.get("id"), "risk": min(risk, 100), "reasons": reasons})
        return {
            "agent": self.name,
            "evaluated": len(transactions),
            "flagged": flagged,
            "note": "Heuristic scoring only. Wire in a real feature store/model before production adjudication.",
        }
