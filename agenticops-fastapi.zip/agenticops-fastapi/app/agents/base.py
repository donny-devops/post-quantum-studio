from abc import ABC, abstractmethod
from typing import Any


class Agent(ABC):
    name: str
    role: str

    @abstractmethod
    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError
