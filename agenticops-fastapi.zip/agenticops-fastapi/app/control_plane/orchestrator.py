from typing import Any

from app.agents.diagnostics import DiagnosticsAgent
from app.agents.fraud import FraudDetectionAgent
from app.agents.optimization import OptimizationAgent
from app.agents.security import SecurityAgent
from app.core.config import get_settings
from app.integrations.telegram import TelegramBotClient
from app.models import WorkflowCreate, WorkflowRecord, WorkflowResponse
from app.storage import db

AGENT_REGISTRY = {
    "diagnostics-agent": DiagnosticsAgent(),
    "optimization-agent": OptimizationAgent(),
    "fraud-detection-agent": FraudDetectionAgent(),
    "security-agent": SecurityAgent(),
}


def build_plan(kind: str) -> list[dict[str, Any]]:
    if kind == "diagnostics":
        return [
            {"agent": "diagnostics-agent", "action": "diagnose", "requires_approval": False},
            {"agent": "optimization-agent", "action": "recommend_optimizations", "requires_approval": False},
        ]
    if kind == "optimization":
        return [{"agent": "optimization-agent", "action": "recommend_optimizations", "requires_approval": False}]
    if kind == "fraud_detection":
        return [{"agent": "fraud-detection-agent", "action": "score_transactions", "requires_approval": False}]
    if kind == "security_scan":
        return [
            {"agent": "diagnostics-agent", "action": "preflight_diagnostics", "requires_approval": False},
            {"agent": "security-agent", "action": "nmap_scan", "requires_approval": get_settings().require_approval_for_nmap},
            {"agent": "optimization-agent", "action": "post_scan_hardening_plan", "requires_approval": False},
        ]
    raise ValueError(f"Unsupported workflow kind: {kind}")


class Orchestrator:
    """Deterministic control plane. Agents execute only after policy/approval gates pass."""

    async def start(self, request: WorkflowCreate, actor: str) -> WorkflowResponse:
        plan = build_plan(request.kind)
        workflow = db.create_workflow(
            kind=request.kind,
            target=request.target,
            context={**request.context, "target": request.target, "notify_telegram_chat_id": request.notify_telegram_chat_id},
            plan=plan,
        )
        workflow = db.update_workflow(workflow.id, status="running")
        return await self._execute_until_blocked(workflow.id, actor)

    async def resume(self, workflow_id: str, actor: str) -> WorkflowResponse:
        workflow = db.get_workflow(workflow_id)
        if workflow.status == "pending_approval":
            pending = db.get_pending_approval_for_workflow(workflow.id)
            if pending:
                return WorkflowResponse(workflow=workflow, message=f"Still waiting for approval {pending.id}")
            if workflow.approval_id:
                approval = db.get_approval(workflow.approval_id)
                if approval.status == "rejected":
                    workflow = db.update_workflow(workflow.id, status="rejected", error=approval.decision_reason or "Approval rejected")
                    return WorkflowResponse(workflow=workflow, message="Workflow rejected by approval gate")
                if approval.status != "approved":
                    return WorkflowResponse(workflow=workflow, message=f"Approval {approval.id} is not approved")
            workflow = db.update_workflow(workflow.id, status="running", approval_id=None)
        return await self._execute_until_blocked(workflow.id, actor)

    async def _execute_until_blocked(self, workflow_id: str, actor: str) -> WorkflowResponse:
        workflow = db.get_workflow(workflow_id)
        accumulated = dict(workflow.result or {})
        context = dict(workflow.context)

        while workflow.current_step < len(workflow.plan):
            step = workflow.plan[workflow.current_step]
            if step.get("requires_approval"):
                existing = db.get_pending_approval_for_workflow(workflow.id)
                approval = existing or db.create_approval(
                    workflow_id=workflow.id,
                    action=step["action"],
                    payload={"step": step, "target": workflow.target, "context": context},
                    requested_by=actor,
                )
                workflow = db.update_workflow(
                    workflow.id,
                    status="pending_approval",
                    approval_id=approval.id,
                    result=accumulated,
                )
                await self._notify_if_configured(context, f"Approval required: {approval.id} for workflow {workflow.id}")
                return WorkflowResponse(workflow=workflow, message=f"Approval required: {approval.id}")

            agent_name = step["agent"]
            agent = AGENT_REGISTRY[agent_name]
            try:
                agent_result = await agent.run({**context, "previous_results": accumulated})
            except Exception as exc:
                workflow = db.update_workflow(workflow.id, status="failed", error=str(exc), result=accumulated)
                await self._notify_if_configured(context, f"Workflow {workflow.id} failed: {exc}")
                return WorkflowResponse(workflow=workflow, message="Workflow failed")

            accumulated[step["action"]] = agent_result
            context["previous_results"] = accumulated
            workflow = db.update_workflow(
                workflow.id,
                current_step=workflow.current_step + 1,
                result=accumulated,
                context=context,
            )

        workflow = db.update_workflow(workflow.id, status="succeeded", result=accumulated)
        await self._notify_if_configured(context, f"Workflow {workflow.id} succeeded")
        return WorkflowResponse(workflow=workflow, message="Workflow succeeded")

    @staticmethod
    async def _notify_if_configured(context: dict[str, Any], text: str) -> None:
        chat_id = context.get("notify_telegram_chat_id")
        if not chat_id:
            return
        client = TelegramBotClient(get_settings())
        if not client.configured:
            return
        try:
            await client.send_message(chat_id=chat_id, text=text)
        except Exception:
            # Notification failures must not mutate workflow state.
            return
